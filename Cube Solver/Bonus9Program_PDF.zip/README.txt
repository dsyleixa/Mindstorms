The software for MindCuber is provided as an executable software file that you can download to the NXT brick using the standard LEGO MINDSTORMS NXT 2.0 software by following these steps:

1. Select �Remote Control� from the �Tools� menu to open the �Remote Control� dialog

2. Select �Connections� from the �Remote Control� dialog to open the connection dialog

3. Scan for your NXT and connect via USB or Bluetooth in the usual way

4. Select the �Memory� tab in the connection dialog

5. Select �Download� from the �Memory� tab and use the file dialog to select the MindCuber.rxe file to download to the NXT

MindCuber is now ready to go!
